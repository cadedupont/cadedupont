// while(true){
    // const divElement = document.createElement('div');
    const imgElement = document.createElement('img');

    // divElement.style = `
    // width: 100%;
    // height: 100%;
    // background-image: url('');
    // z-index: 1000;
    // position: absolute;
    // left: 0;
    // top: 0;
    // `;

    const x = Math.random() * screen.availWidth;
    const y = Math.random() * screen.availHeight;
    const imageNum = Math.floor(Math.random() * 4);


    imgElement.style = `
    width: 50%;
    height: 50%;
    z-index: 1000;
    position: absolute;
    left: x;
    right: y;
    `;

    switch(imageNum) {
        case 0:
            imgElement.src = '../res/devito1.png';
            break;
        case 1:
            imgElement.src = '../res/devito2.png';
            break;
        case 2:
            imgElement.src = '../res/devito3.png';
            break;
        case 3:
            imgElement.src = '../res/devito4.png';
            break;
    }

    document.body.style.overflow = 'hidden';

    document.body.appendChild(imgElement);

    console.log(imgElement);    
// }