document.body.style = `
font-size: 100px !important;
font-family: "Comic Sans" !important;
color: red;
`;

console.log(document.body)